package static_demos;
//car scenario for need of static variable

public class try1 {
	private String name;
    private String engine;
    
    public static int numberOfCars;
    
    public try1(String name, String engine) {
        this.name = name;
        this.engine = engine;
        numberOfCars++;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}
    
    public static void main(String args[]) {
    	try1 obj1 = new try1("Jaguar", "V8");
    	try1 obj2 = new try1("Jaguar", "V8");
    	System.out.println("total number of cars: " + numberOfCars);
    	//to be accessed using classname.membername
    	System.out.println("static variable value in another class: " + execute.var1);
    	execute obj3 = new execute();
    	System.out.println("staitic var value using object ref :" + obj3.var1);
    	obj3.var1+=10;
    	//value can be accessed and modified using object ref as well
    	System.out.println("static var value after modification :" + execute.var1);
    
    }
}

//even if a main method is declared in default class it will not be considered. The execution will start
//from the public class and main method inside it 
class execute{
	public static int var1 = 1;  
//	public static void main(String args[]) {
//    	try1 obj1 = new try1("Jaguar", "V8");
//    	try1 obj2 = new try1("Jaguar", "V8");
//    	System.out.println("total number of cars: " + try1.numberOfCars);
//    }
}
