package static_demos;
import java.util.*;
public class try2 {
	public static List<String> ranks = new LinkedList<>();
	public static int var1;
    static {
    	System.out.println("inside1");
        ranks.add("Lieutenant");
        ranks.add("Captain");
        ranks.add("Major");
    }
    
    static {
    	System.out.println("inside2");
        ranks.add("Colonel");
        ranks.add("General");
    }
    
    static {
    	System.out.println("inside3");
    	var1 = 10;
    }
    public static void main(String args[]) {
    	System.out.println(ranks);
    	//multiple static blocks are executed in their written order
    	System.out.println("value of var1 : " + try2.var1);
    	System.out.println("____________");
    	//class is loaded even for the below line when we access static variable of the class
//    	System.out.println(execute1.var1);
    	//class is not loaded with the below line as it is only reference to the class and obj not created
//    	execute1 obj1 = null;
    	System.out.println("____________");
    	//***till now the class execute1 is not loaded, so inside4 is not displayed****//
    	//static blocks are executed before constructors.  
    	execute1 obj1 = new execute1(1000);
    	System.out.println("value of static variable var1 : " + execute1.var1);
    	System.out.println("value of instance variable var2 : "+ obj1.var2);
    	//***when you invoke that var1 of execute1 class, then that class is loaded into memory and once
    	//the static blocks are executed//
    	
    }
}

class execute1{
	public static int var1;
	public int var2;
	static {
    	System.out.println("inside4");
    	int var2;
    	var1 = 100;
    	//only static and local variables can be used inside a static block
    	//var1 is static and var2 is local
    	var2 = 200;
    	System.out.println("value of local variable var2 : " + var2);
    }
	
	static {
    	System.out.println("inside5");
    	var1 = 200;
    }
	public execute1(int var2) {
		System.out.println("inside constructor");
		this.var2=var2;
		//initializing in constructor
		var1=300;
		}
}