package static_demos;

public class try3 {
	public static int var1;
	static {
		var1 = 10;
	}
	
	public static void main(String args[]) {
		//cannot access directly as var2 is a private variable
		//so getter and setter will need object reference if they are not made as static
		System.out.println(execute2.getVar2());
		//calling a static method
		System.out.println(execute2.calc_disc_amt());
		//to call calc_amt we need object of the class
		execute2 obj1 = new execute2();
		System.out.println(obj1.calc_amt());
		//accessing static methods using object reference. It can be done but gives a warning
		System.out.println(obj1.calc_disc_amt());
		
	}
	
}
 
class execute2{
	private static int var2;
	public static int price;
	public int price1 = 100;
	public static int discount;
	static {
		var2 = 15;
		discount = 3;
		price = 1000;
		// non static variables cannot be instantiated in static block
		//price1=100;
		
	}
	public static int calc_disc_amt() {
		//static and local variables can be accessed inside a static method
		int amt = (int)(price * (discount/100.0));
		//cannot use instance variables inside a static method
//		System.out.println(this.price1);
		return amt;
		
	}
	
	public int calc_amt() {
		int amt = (int)(price * (discount/100.0));
		System.out.println(this.price1);
		return amt;
	}
	
	//static getter setters for static private variables
	public static int getVar2() {
		return var2;
	}
	public static void setVar2(int var2) {
		execute2.var2 = var2;
	}
	
	
	
}
