package Overload_demos;

public class Shape {
	public float calculateArea(float r) {
		return 3.14f * r * r;
	}

	// number of parameters are differing (int,int)
	public float calculateArea(int l, int b) {
		System.out.println("inside rectangle");
		return l * b;
	}
	
	//number of parameters same but data type different(float , float)
	public float calculateArea(float a, float b) {
		System.out.println("inside eclipse");
		return (float) (a*b*3.14);
	}
	
	//modify data type in different orders (int,float) and (float , int) and tryout
	// try by just deferring in return types and everything else same 
	public static void main(String[] args) {

		Shape shape = new Shape();
		Shape.main(10);

		float circleArea = shape.calculateArea(1.7f);
//		float rectangleArea = shape.calculateArea(2.5f, 3.4f);
		float eclipseArea = shape.calculateArea(2,3);
		
		//after modifying data types
//		float rectangleArea = shape.calculateArea(2, 3.4f);
//		System.out.println("-----------------------");
//		float eclipseArea = shape.calculateArea(2.5f,3);
		
		System.out.println("Area of circle: " + circleArea);
//		System.out.println("Area of rectangle: " + rectangleArea);
		System.out.println("Area of eclipse: " + eclipseArea);

		// Invoke the method to find the area of triangle
		// Display the area of triangle
	}
	//main method can also be overloaded
	public static void main() {
		System.out.println("main method overloading");
	}
	
	public static void main(int a) {
		System.out.println("main method overloading");
		System.out.println(a);
	}
}
