package Overload_demos;
//type promotion happened from int to long
public class promote1 {
	
	void sum(int x, long y)  { 
		System.out.println("inside 1");
        System.out.println(x+y);  
    }  
	
    void sum(int x, int y, int z) {
    	System.out.println("inside 2");
        System.out.println(x+y+z);  
    }  
    
    public static void main(String[] args)  
    {  
        promote1 s = new promote1();  
        s.sum(40, 40);  
        s.sum(40, 40, 40);  
    }  
}
