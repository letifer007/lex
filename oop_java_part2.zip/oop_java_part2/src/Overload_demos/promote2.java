package Overload_demos;
// no type promotion when data types match
public class promote2 {
	void sum(int x, int y)  
    {  
        System.out.println("yahoo");  
    }  
//    void sum(long x, long y)  
//    {  
//    	System.out.println(x+y);
//        System.out.println("lalala");  
//    }  
    void sum(float x, float y)  
    {  
    	//x,y --> float types 
    	System.out.println(x+y);
        System.out.println("pppppp");  
    }  
    
    void sum(double x, double y)  
    {  
        System.out.println("lalalaaaaa");  
    } 
    
    
    public static void main(String[] args)  
    {  
        promote2 s = new promote2();  
        //int,int
//        s.sum(100/3,100/3); 
//        int x = 'a'+1;
//        System.out.println(x);
        s.sum('a');
    }  
    
    
    
    void sum(float a)  
    {  
    	System.out.println("float");
        System.out.println(a);  
    }
    
//    void sum(int a)  
//    {  
//    	System.out.println("int");
//        System.out.println(a);  
//    }
}
