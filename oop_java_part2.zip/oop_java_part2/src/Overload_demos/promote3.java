package Overload_demos;

public class promote3 {
	void sum(int x, long y)  
    {  
        System.out.println("yahoo");  
    }  
//	int sum(int x,long y)
//	{
//		return 10;
//	}
	
	// it is ambiguous, if we make int y as long y in below method, it is no more ambiguous
    void sum(long x, int y)  
    {  
        System.out.println("lalala");  
    }  
    public static void main(String[] args)  
    {  
        promote3 s = new promote3();  
        //the methods become ambiguous when we pass int,int types 
        s.sum(40L, 40);  
    }  
}
