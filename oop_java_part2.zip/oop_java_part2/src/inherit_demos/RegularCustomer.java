package inherit_demos;
//creates is-a relationship
public class RegularCustomer extends Customer{
	//default const is provided
	//it will first call the non parameterized constructor of parent class 
	public float discount;
	
//	static {
//		System.out.println("stat inside reg cust");
//	}
	
	private RegularCustomer() {
		//implicit call to parent class NPC happens
		System.out.println("NPC of regular customer");
	}
	
	public RegularCustomer(String customerId,String customerName,long contactNumber,float discount) {
		//can be done but it is repitetion of code
//		this.customerId=customerId;
//		this.customerName=customerName;
//		this.setContactNumber(contactNumber);
		
		//calling parameterless constructor --> equivalent to implicit call
//		super();
		
		//using super to call parameterized constructor of parent class
//		super(customerId,customerName,contactNumber);
		
		//using this() to invoke constructor of the same class
		this();
		this.discount=discount;
		
	}
	public void reg_disp() {
		System.out.println(this.discount);
		//accessing of public attributes of parent class
		System.out.println(this.customerId);
		//accessing public methods of parent class
		this.cust_disp();
		//accessing private instance variable
		System.out.println("using getter: " + this.getContactNumber());
		
	}
}
