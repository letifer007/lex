package inherit_demos;

public class Customer {
	public String customerId;
	public String customerName;
	private long contactNumber;
	
//	static {
//		System.out.println("stat inside customer");
//	}
		
	public Customer() {
		System.out.println("NPC of customer class");
	}
	
	public Customer(String customerId,String customerName,long contactNumber) {
		System.out.println("PC of customer class");
		this.customerId=customerId;
		this.customerName=customerName;
		this.contactNumber=contactNumber;
	}
    
	public Customer(String customerId,long contactNumber,String customerName) {
		System.out.println("overloaded constructor");
		this.customerId=customerId;
		this.customerName=customerName;
		this.contactNumber=contactNumber;
	}
	
	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public void cust_disp() {
	System.out.println(this.customerName);
	System.out.println(this.contactNumber);
     }
	

}
