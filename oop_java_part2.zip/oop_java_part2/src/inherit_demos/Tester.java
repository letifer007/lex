package inherit_demos;

public class Tester {
	public static void main(String args[]) {
//		RegularCustomer obj1 = new RegularCustomer();
		System.out.println("---------------------");
		RegularCustomer obj2 = new RegularCustomer("1001","jack",9999999999L,10.0f);
		obj2.reg_disp();
		
		System.out.println("---------------------");
//		System.out.println(obj1.getContactNumber());
	}
	
}
