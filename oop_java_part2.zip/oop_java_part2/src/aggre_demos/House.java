package aggre_demos;

public class House {
	private String doorNo;
	public String street;
	
	public House(String doorNo,String street) {
		this.doorNo = doorNo;
		this.street = street;
	}

	public String getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	
	
}
