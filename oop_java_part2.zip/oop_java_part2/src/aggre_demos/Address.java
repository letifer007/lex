package aggre_demos;

public class Address {
	private String city;
	public String state;
	private House house;
	
	public Address(String city,String state, House house1) {
		this.city=city;
		this.state=state;
		this.house=house1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public House getHouse() {
		return house;
	}

	public void setHouse(House house) {
		this.house = house;
	}
	
	public void update(House h1) {
//		this.house.setDoorNo(h1.getDoorNo());
		this.house=h1;
	}
	

}
