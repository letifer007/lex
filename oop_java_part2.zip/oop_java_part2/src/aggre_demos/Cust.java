package aggre_demos;
//objects of one class are made as instance variables inside another class --> aggregation
public class Cust {
	public String customerName;
	public int customerId;
	
	//creating has-a relation
	private Address[] add1;
	
	public Cust(int customerId,String customerName,Address[] add1){
		this.customerId=customerId;
		this.customerName=customerName;
		this.add1=add1;
	}
	
	
	public Address[] getAdd1() {
		return add1;
	}

	public void setAdd1(Address[] add1) {
		this.add1 = add1;
	}
	
//	public int calc_price(int price) {
//		if(this.add1.getCity()=="mysore") {
//			price = (int)(price * 0.9);
//		}
//		return price;
//	}
	
	public void display_details() {
		//when all are public 
//		System.out.println(this.add1.house.doorNo);
		
		//when all are private and single address object
//		System.out.println(this.add1.getHouse().getDoorNo());
		
		//multiple addresses
		for(Address i : add1) {
			System.out.println(i.getHouse().getDoorNo());
		}
		
		
	}
	
	
	
	
}
