package aggre_demos;



public class Tester {
	public static void main(String args[]) {
		House h1 = new House("2906","6th cross");
		House h2 = new House("2888","7th lane");
		
		Address add1 = new Address("bangalore","karnataka",h1);
		Address add2 = new Address("mysore","karnataka",h1);
		
		add1.update(h2);
		System.out.println(add2.getHouse().getDoorNo());
		System.out.println(add1.getHouse().getDoorNo());
		System.out.println(add2.getHouse().street);
		System.out.println(add1.getHouse().street);
		
//		Address add2 = new Address("bangalore","karnataka",h2);
//		Address add1 = new Address("mysore","karnataka",h1);
		
		//when house is not allocated
		Address add3 = new Address("mysore","karnataka",null);
		//setting it here with h1
		add3.setHouse(h1);
		
		//for array of objects
//		Address[] arr1 = {add1,add2};
//		Cust cust1 = new Cust(1001,"ram",arr1);
//		System.out.println("cust id is : "+cust1.customerId);
		
		//when add1 is public in customer class 
//		System.out.println("add obj is : "+cust1.add1);
//		System.out.println("cust city is : " +cust1.add1.city);
		
		//when add1 is private in customer class
//		System.out.println("add obj is : "+cust1.getAdd1());
//		System.out.println("cust city is : " +cust1.getAdd1().city);
		
		//when city is private in customer class
//		System.out.println("add obj is : "+cust1.add1);
//		System.out.println("cust city is : " +cust1.add1.getCity());
		
		//when city and address both are private 
//		System.out.println("add obj is : "+cust1.getAdd1());
//		System.out.println("cust city is : " +cust1.getAdd1().getCity());
		
		//for single address
//		cust1.display_details();
//		System.out.println(cust1.getAdd1().getHouse().getDoorNo());
		
		//for array of objects i.e addresses
//		System.out.println("door no's of customer available: ");
//		cust1.display_details();
	}
	
	
}
