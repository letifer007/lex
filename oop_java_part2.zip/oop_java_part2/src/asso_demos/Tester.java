package asso_demos;

public class Tester {
	public static void main(String args[]) {
		//both objects can exist independently 
		Customer obj1 = new Customer("jack",23,"9999999999");
		Payment obj2 = new Payment("card");
		Payment obj3 = new Payment("e-wallet");
		Payment[] arr = {obj2,obj3};
		
		//only while calling the method we need to pass this object
		//scope of payment object is only inside the method
		obj1.payment(arr);
		System.out.println("-----------");
		Customer.display(obj2);
		
	}
}
