package asso_demos;
//objects of other classes are used as local variables inside methods --> association
public class Customer {
	public String name;
	public int age;
	public String phoneNo;
	static {
		//objects can be created inside static block and static methods and can be used
		Payment obj1 = new Payment("card");
		System.out.println("inside static block : " + obj1.getType());
	}
	
	public static void display(Payment pay) {
		//passing an object inside a static method and using it
		System.out.println(pay.getType());
	}
	public Customer(String name,int age,String phoneNo) {
		this.name=name;
		this.age=age;
		this.phoneNo=phoneNo;
		
	}
	public void payment(Payment[] pay) {
		//if type is public
//		if(pay.type=="card") {
//			System.out.println("card payment");
//		}
//		else if(pay.type=="e-wallet") {
//			System.out.println("wallet payment");
//		}
		
		//if type is private
//		if(pay.getType()=="card") {
//			System.out.println("card payment");
//		}
//		else if(pay.getType()=="e-wallet") {
//			System.out.println("wallet payment");
//		}
		
		//if we pass arr of objects
		for(Payment i: pay) {
			if(i.getType()=="card") {
				System.out.println("payment through card");
			}
		}
	}
}
